import{c as r,s as e}from"./flowDiagram-HODETNUW.BHzOHola.js";import{_ as a}from"./index.Bs2MQIoA.js";import"./chunk-5VM5RSS4.DTIwa9gy.js";import"./chunk-XXDRQBXY.msNWU8SZ.js";import"./chunk-POPQ4Y6H.BfZXRaJQ.js";import"./chunk-F27PBJKO.FD9yieNl.js";import"./channel.BUYV8W7j.js";import"./preload-helper.CLcXU_4U.js";import"./index.DwgVoXdh.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
